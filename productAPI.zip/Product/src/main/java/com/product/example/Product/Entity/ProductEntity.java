package com.product.example.Product.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ProductEntity {

	private int productId;
	private String name;
	private String version;
	private int price;
	
	@Id
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	

	
	

}
