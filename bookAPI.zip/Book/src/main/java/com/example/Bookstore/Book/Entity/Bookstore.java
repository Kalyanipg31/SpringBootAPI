package com.example.Bookstore.Book.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bookstore {
	
	private int bookId;
	private String bookName;
	private String autherName;
	
	@Id
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAutherName() {
		return autherName;
	}
	public void setAutherName(String autherName) {
		this.autherName = autherName;
	}

	
	

}
