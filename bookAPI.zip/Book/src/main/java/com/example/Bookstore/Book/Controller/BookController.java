package com.example.Bookstore.Book.Controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Bookstore.Book.Entity.Bookstore;


@RestController
public class BookController {

	@Autowired
	private SessionFactory sf;

	@GetMapping("getlistofAllBooks")
	public List<Bookstore> getlistofAllBooks() {
		Session session=sf.openSession();
		Criteria criteria=session.createCriteria(Bookstore.class);
		List<Bookstore> list=criteria.list();
		return list;
	}
	
	@PostMapping("addnewBooks")
	public String insertNewBooks(@RequestBody Bookstore bookstore) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(bookstore);
		tr.commit();
		return "data inserted successfully...";
	}
	
	@PutMapping("updateBookDetails")
	public String updateBookDetails(@RequestBody Bookstore bookstore) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(bookstore);
		tr.commit();
		return "data updated successfully...";
	}
	
	
}
