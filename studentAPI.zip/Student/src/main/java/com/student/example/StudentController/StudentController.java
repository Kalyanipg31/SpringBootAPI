package com.student.example.StudentController;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.example.StudentEntity.Studententity;

@RestController
public class StudentController {
	
	@Autowired
	private SessionFactory sf;
	
	@PostMapping("addstudent")
	public String saveStudent(@RequestBody Studententity studententity) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(studententity);
		tr.commit();
		return "data inserted successfully...";
		
	}
	
	
	@GetMapping("getStudentById/{id}")
	public Studententity getStudentById(@PathVariable("id") int id ) {
		Session session=sf.openSession();
		Studententity studententity=session.load(Studententity.class,2);
		return studententity;
	}
	
	@GetMapping("getStudents")
	public List<Studententity> getStudents() {
		Session session=sf.openSession();
		Criteria criteria=session.createCriteria(Studententity.class);
		List<Studententity> list=criteria.list();
		return list;
	}
	
	@DeleteMapping("deleteStudent/{id}")
	public String deleteStudent(@PathVariable("id") int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Studententity studententity=session.load(Studententity.class,1);
		session.delete(studententity);
		tr.commit();
		return "data deleted successfully...";

		
	}

}
