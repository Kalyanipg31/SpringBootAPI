package com.example.BusDemo.Bus.Controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.BusDemo.Bus.Entity.Bus;


@RestController
public class BusController {

	@Autowired
	private SessionFactory sf;
	
	@GetMapping("getAlldetails")
	public List<Bus> getAllBusDetails() {
		Session session=sf.openSession();
		Criteria criteria=session.createCriteria(Bus.class);
		List<Bus> list=criteria.list();
		return list;
	}
	
	@PostMapping("addBusDetails")
	public String insertDetails(@RequestBody Bus bus) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(bus);
		tr.commit();
		return "data inserted successfully...";
	}
	
	@PutMapping("updatbusdetails")
	public String updateBusDetails(@RequestBody Bus bus) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(bus);
		tr.commit();
		return "data updated successfully...";
	}
	
	@DeleteMapping("deleteBus/{id}")
	public String deleteBus(@PathVariable("id") int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Bus bus=session.load(Bus.class,3);
		session.delete(bus);
		tr.commit();
		return "data deleted successfully...";
		
	}
}
